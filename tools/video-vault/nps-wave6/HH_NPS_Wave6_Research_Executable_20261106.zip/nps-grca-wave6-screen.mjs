#!/usr/bin/env node
/**
 * NPS Grand Canyon filmed source acquisition. Official nps.gov ONLY.
 * One-time editorial artifacts; no Cloudflare, Supabase, public/, publication or customer data.
 * Multiple different NPS media UUIDs on a group page may be different source shoots;
 * copies/crops of an identical UUID or hash count as ONE original.
 */
import {readFileSync,writeFileSync,mkdirSync,statSync,rmSync,mkdtempSync,createWriteStream} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {tmpdir} from 'node:os';
import {pipeline} from 'node:stream/promises';
import {Readable,Transform} from 'node:stream';

const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'../../..');
const manifestPath=resolve(ROOT,'data/video-catalog/nps-grca-research-54-20261106.json');
// NPS legacy video IDs use 8-4-4-16; newer media use standard 8-4-4-4-12.
const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-(?:[a-f0-9]{16}|[a-f0-9]{4}-[a-f0-9]{12})$/;
const PAGE=/^https:\/\/www\.nps\.gov\/grca\/learn\/photosmultimedia\/b-roll_hd(?:01|02|10|11|14|15|16|25)\.htm$/;
const MAX_MP4=46_000_000;
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const clipName=s=>`grca-${s.id}`;
export const OFFICIAL_INDEX='https://www.nps.gov/grca/learn/photosmultimedia/b-roll_hd_index.htm';
export function validateSources(data){
 if(data?.schemaVersion!=='hh-nps-grca-research-batch-v1'||data.individualOfficialMediaIds!==54||
    !Array.isArray(data.sources)||data.sources.length!==54||data.actualMediaDownloaded!==false||
    data.cloudflareUploaded!==false)throw Error('UNSAFE_GRCA_MANIFEST');
 const ids=new Set(), pages=new Set();
 for(const a of data.sources){
  if(!UUID.test(a.id)||a.sourceAssetId!==a.id||a.provider!=='nps_grca'||
     !PAGE.test(a.sourcePage)||ids.has(a.id)||a.countedAsOriginal!==false||
     a.generatorEligible!==false||a.stage!=='CANDIDATE_RESEARCH_ONLY')throw Error('UNSAFE_NPS_SOURCE');
  ids.add(a.id);pages.add(a.sourcePage);
 }
 if(pages.size!==8)throw Error('INCOMPLETE_GROUP_PAGES');
 return data.sources;
}
export function isAllowedMediaUrl(candidate){
 try{const u=new URL(candidate);
  return u.protocol==='https:'&&u.hostname==='www.nps.gov'&&u.username===''&&u.password===''&&
    /^\/nps-audiovideo\/audiovideo\/[a-zA-Z0-9_-]+\.mp4$/i.test(u.pathname)&&
    !u.search&&!u.hash;
 }catch{return false;}
}
export function extractMp4Urls(html){
 // NPS player pages sometimes use a different rendition GUID than media ID
 // and may use relative <source> paths, escaped JSON slashes or absolute URLs.
 const clean=String(html||'').replace(/\\\//g,'/').replaceAll('&amp;','&')
  .replaceAll('\\u002F','/').replaceAll('\\u003A',':');
 const direct=[...clean.matchAll(/https:\/\/[^\s"'<>\\]+?\.mp4(?:\?[^\s"'<>\\]*)?/gi)].map(x=>x[0]);
 const relative=[...clean.matchAll(/(?:^|["'\s(])\/nps-audiovideo\/audiovideo\/[A-Za-z0-9_-]+\.mp4/gi)]
  .map(x=>'https://www.nps.gov'+x[0].slice(x[0].indexOf('/nps-audiovideo')));
 return [...new Set([...direct,...relative].filter(isAllowedMediaUrl))];
}
export function staticCandidates(id){
 if(!UUID.test(id))throw Error('BAD_NPS_ID');
 const out=[];
 for(const root of [id.toLowerCase(),id.toUpperCase()])
  for(const size of ['720p','480p','360p','1080p','']){
   const url=`https://www.nps.gov/nps-audiovideo/audiovideo/${root}${size}.mp4`;
   if(isAllowedMediaUrl(url))out.push(url);
  }
 return [...new Set(out)];
}
const cmd=(name,args,{timeout=60000,binary=false}={})=>{
 const result=spawnSync(name,args,{encoding:binary?null:'utf8',shell:false,timeout,maxBuffer:8_000_000});
 if(result.error||result.status!==0)throw Error(`${name}_FAILED:${String(result.stderr||result.error).slice(-160)}`);
 return result.stdout;
};
async function fetchHtml(url,maxBytes=1_600_000){
 const r=await fetch(url,{redirect:'error',signal:AbortSignal.timeout(20000),headers:{Accept:'text/html'}});
 if(!r.ok||!String(r.headers.get('content-type')||'').includes('text/html'))throw Error('NPS_PAGE_UNAVAILABLE_'+r.status);
 const n=Number(r.headers.get('content-length'));
 if(n>maxBytes)throw Error('NPS_PAGE_TOO_LARGE');
 const text=await r.text();if(Buffer.byteLength(text)>maxBytes)throw Error('NPS_HTML_TOO_LARGE');return text;
}
function officialPageProof(html,id){
 const content=String(html||'');
 const plain=content.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ');
 if(!/public\s+domain/i.test(plain)||
    !/without a release from the National Park Service/i.test(plain)||
    !content.toLowerCase().includes(id.toLowerCase()))throw Error('PUBLIC_DOMAIN_SOURCE_ID_UNVERIFIED');
 return true;
}
async function existsVideo(url){
 if(!isAllowedMediaUrl(url))return false;
 try{
  const head=await fetch(url,{method:'HEAD',redirect:'manual',signal:AbortSignal.timeout(10000)});
  const type=String(head.headers.get('content-type')||'');
  const bytes=Number(head.headers.get('content-length'));
  if(head.ok&&(!type||type.includes('video')||type.includes('octet-stream'))&&(!bytes||bytes<=MAX_MP4))return true;
 }catch{}
 // Some NPS/CDN routes do not implement HEAD but do accept normal GET + Range.
 try{
  const r=await fetch(url,{method:'GET',headers:{Range:'bytes=0-1023'},redirect:'manual',signal:AbortSignal.timeout(12000)});
  if(!r.ok||!r.body)return false;
  const reader=r.body.getReader();const {value}=await reader.read();
  await reader.cancel().catch(()=>{});
  // MP4 ftyp atom may start after a 4-byte box length field.
  return value instanceof Uint8Array&&value.length>=12&&Buffer.from(value).toString('ascii',4,8)==='ftyp';
 }catch{return false;}
}
async function resolveVideo(s,groupHtml){
 officialPageProof(groupHtml,s.id);
 const embeds=[`https://www.nps.gov/media/video/embed.htm?id=${s.id.toUpperCase()}`,
  `https://www.nps.gov/media/video/view.htm?id=${s.id.toUpperCase()}`];
 const urls=[];
 // Group pages contain other videos, so only accept URLs with this video ID.
 urls.push(...extractMp4Urls(groupHtml).filter(u=>u.toLowerCase().includes(s.id.toLowerCase())));
 let viewerHtmlFound=0,viewerCandidates=0;
 for(const page of embeds){
  try{const html=await fetchHtml(page);viewerHtmlFound++;
    const candidates=extractMp4Urls(html);viewerCandidates+=candidates.length;
    // Viewer and embed pages are scoped by the exact source ID, so their
    // official renditions need not share that ID in their filename.
    urls.push(...candidates);
  }catch{}
 }
 for(const url of [...new Set([...urls,...staticCandidates(s.id)])]){
  if(await existsVideo(url))return url;
 }
 throw Error(`OFFICIAL_MP4_RENDITION_NOT_FOUND:viewerHtml=${viewerHtmlFound}:viewerUrls=${viewerCandidates}`);
}
async function downloadBounded(url,filename){
 if(!isAllowedMediaUrl(url))throw Error('UNSAFE_DOWNLOAD_HOST');
 const r=await fetch(url,{redirect:'error',signal:AbortSignal.timeout(85000)});
 if(!r.ok||!r.body)throw Error('VIDEO_DOWNLOAD_FAILED_'+r.status);
 const len=Number(r.headers.get('content-length'));
 if(len>MAX_MP4)throw Error('VIDEO_TOO_LARGE');
 let length=0;
 const throttle=new Transform({transform(part,_,cb){length+=part.length;
  if(length>MAX_MP4)cb(Error('VIDEO_EXCEEDS_BUDGET'));else cb(null,part);
 }});
 await pipeline(Readable.fromWeb(r.body),throttle,createWriteStream(filename));
 if(length<50000)throw Error('VIDEO_TOO_SHORT_BYTES');
 const b=readFileSync(filename);
 if(b.toString('ascii',4,8)!=='ftyp')throw Error('NOT_MP4');
 return {size:length,sha256:sha(b)};
}
function probe(file,min=5.2){
 const i=JSON.parse(cmd('ffprobe',['-v','error','-show_streams','-show_format','-of','json',file]));
 const v=i.streams?.find(x=>x.codec_type==='video');
 const seconds=Number(i.format?.duration);
 const nums=String(v?.avg_frame_rate||'0/0').split('/').map(Number),fps=nums[1]?nums[0]/nums[1]:0;
 if(!v||!Number.isFinite(seconds)||seconds<min||seconds>900||v.width<600||v.height<360||fps<12||fps>120)
  throw Error('SOURCE_VIDEO_UNSUITABLE');
 return {codec:v.codec_name,pixFmt:v.pix_fmt,width:v.width,height:v.height,fps,seconds};
}
function quality(file){
 const p=cmd('ffmpeg',['-v','error','-nostdin','-i',file,'-vf','fps=1,scale=48:27,format=gray',
   '-frames:v','5','-f','rawvideo','pipe:1'],{timeout:30000,binary:true});
 let motion=0,c=0;const size=48*27;
 if(p.length<size*4)throw Error('TOO_FEW_MOVING_FRAMES');
 let prior=null;for(let i=0;i<5;i++){
  const f=p.subarray(i*size,(i+1)*size);if(f.length<size)break;
  let sum=0,sq=0,d=0;for(let k=0;k<size;k++){
   let v=f[k];sum+=v;sq+=v*v;if(prior)d+=Math.abs(v-prior[k]);
  }
  c=Math.max(c,Math.sqrt(Math.max(0,sq/size-(sum/size)**2)));
  if(prior)motion+=d/size;prior=f;
 }
 return {motion:+(motion/4).toFixed(2),contrast:+c.toFixed(2),technicalVisualCandidate:motion/4>=0.55&&c>=11};
}
function encode(input,folder,start,aspect){
 const specs=aspect==='landscape'?[1280,720]:[720,1280];const [w,h]=specs;
 const output=join(folder,aspect+'.mp4');
 cmd('ffmpeg',['-v','error','-y','-nostdin','-ss',String(start),'-i',input,'-t','5','-an',
  '-vf',`fps=24,scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h},setsar=1,format=yuv420p`,
  '-c:v','libx264','-preset','veryfast','-threads','2','-crf',aspect==='landscape'?'24':'27',
  '-movflags','+faststart','-metadata','comment=NPS public domain B-roll edited; no NPS endorsement',output],{timeout:100000});
 const meta=probe(output,4.8);
 if(meta.codec!=='h264'||meta.pixFmt!=='yuv420p'||meta.width!==w||meta.height!==h||
   Math.abs(meta.seconds-5)>.1||Math.abs(meta.fps-24)>.1)throw Error('ENCODE_NOT_CANONICAL');
 cmd('ffmpeg',['-v','error','-xerror','-nostdin','-i',output,'-f','null','-'],{timeout:55000});
 return {...meta,...quality(output),bytes:statSync(output).size,sha256:sha(readFileSync(output)),file:aspect+'.mp4'};
}
async function main(){
 const args=process.argv.slice(2);
 if(args.length!==1||!/^--shard=[0-3]$/.test(args[0]))throw Error('INVALID_SHARD');
 const shard=Number(args[0].split('=')[1]);
 const sources=validateSources(JSON.parse(readFileSync(manifestPath,'utf8')));
 const chosen=sources.filter((_,i)=>i%4===shard);
 const out=resolve(ROOT,`artifacts/nps-grca-wave6-shard${shard}`);mkdirSync(out,{recursive:true});
 const groupCache=new Map(),report={version:'nps-grca-wave6-physical-v1',shard,startedAt:new Date().toISOString(),
  sourceCandidates:chosen.length,publisher:'U.S. National Park Service',rights:'official B-roll group-page public domain only',
  outputStatus:'EDITORIAL_REVIEW_ONLY',cloudflareR2Uploads:0,generatorEligible:0,passed:[],failed:[]};
 for(const s of chosen){const tmp=mkdtempSync(join(tmpdir(),'hh-grca-'));
  try{let group=groupCache.get(s.sourcePage);
   if(!group){group=await fetchHtml(s.sourcePage);groupCache.set(s.sourcePage,group);}
   const url=await resolveVideo(s,group);
   const filename=join(tmp,'source.mp4');
   const raw=await downloadBounded(url,filename);const meta=probe(filename);
   const start=Math.max(0.1,Math.min(meta.seconds-5,Math.floor(meta.seconds*.25)));
   const dir=join(out,clipName(s));mkdirSync(dir,{recursive:true});
   const landscape=encode(filename,dir,start,'landscape');
   const portrait=encode(filename,dir,start,'portrait');
   cmd('ffmpeg',['-v','error','-y','-nostdin','-i',join(dir,'landscape.mp4'),'-vf','fps=1.8,scale=320:180,tile=3x3:nb_frames=9','-frames:v','1',join(dir,'contact.jpg')]);
   cmd('ffmpeg',['-v','error','-y','-nostdin','-ss','2','-i',join(dir,'portrait.mp4'),'-vf','scale=360:640','-frames:v','1','-q:v','4',join(dir,'poster.jpg')]);
   report.passed.push({id:s.id,sourcePage:s.sourcePage,officialMediaUrl:url,originalId:s.id,
    rawFileSha256:raw.sha256,rawFileBytes:raw.size,sourceDurationSeconds:meta.seconds,
    sourceNativeAspect:meta.width>meta.height?'landscape':'portrait',tags:s.visualTags,
    category:s.visualTags.includes('water')?'water':'nature',sampleStartSeconds:start,
    licensed:'public_domain_official_archive',noNpsEndorsement:true,peopleLogosUnverified:true,
    artApproved:false,approvedForPublication:false,cloudflareR2UploadVerified:false,
    files:{landscape,portrait,contact:'contact.jpg',poster:'poster.jpg'}});
   console.log('GRCA_PHYSICAL_PASS',s.id,raw.size);
  }catch(e){report.failed.push({id:s.id,error:String(e.message||e).slice(0,230)});
   console.log('GRCA_PHYSICAL_HOLD',s.id,String(e.message||e).slice(0,230));
  }finally{rmSync(tmp,{force:true,recursive:true});}
 }
 report.completedAt=new Date().toISOString();report.physicalOriginals=report.passed.length;
 report.mp4Count=report.passed.length*2;
 writeFileSync(join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
 writeFileSync(join(out,'README.md'),'Grand Canyon NPS Wave 6 editorial QA only. All sources public-domain as declared on NPS B-roll group pages. Clips shortened and reformatted, 9:16 is a reframe not a new camera original. No Government endorsement, no publication or Cloudflare R2 upload; all frames need independent artistic/rights review.\n');
 console.log('GRCA_RECEIPT',JSON.stringify({shard,physicalOriginals:report.physicalOriginals,failed:report.failed.length,mp4:report.mp4Count}));
 if(report.physicalOriginals===0)process.exitCode=1;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))
 main().catch(e=>{console.error('GRCA_FATAL',String(e));process.exitCode=1;});
