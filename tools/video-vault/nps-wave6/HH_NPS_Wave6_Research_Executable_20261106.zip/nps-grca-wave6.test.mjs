import {test} from 'node:test';
import {strict as assert} from 'node:assert';
import {validateSources,isAllowedMediaUrl,extractMp4Urls,staticCandidates,OFFICIAL_INDEX} from './nps-grca-wave6-screen.mjs';
function source(i,group){const id='00000000-0000-4000-8000-'+String(i).padStart(12,'0');return {id,sourceAssetId:id,provider:'nps_grca',sourcePage:`https://www.nps.gov/grca/learn/photosmultimedia/b-roll_hd${group}.htm`,countedAsOriginal:false,generatorEligible:false,stage:'CANDIDATE_RESEARCH_ONLY'};}
const groupCodes=['01','02','10','11','14','15','16','25'];
function fixture(){return {schemaVersion:'hh-nps-grca-research-batch-v1',individualOfficialMediaIds:54,actualMediaDownloaded:false,cloudflareUploaded:false,sources:Array.from({length:54},(_,i)=>source(i,groupCodes[i%8]))};}
test('all 54 stable NPS identities allow distinct media on same official pages',()=>{assert.equal(validateSources(fixture()).length,54);});
test('no duplicate original UUIDs, forged pages or falsely generator eligible',()=>{let data=fixture();data.sources[2].id=data.sources[1].id;assert.throws(()=>validateSources(data));data=fixture();data.sources[1].sourcePage='https://evil.net/video';assert.throws(()=>validateSources(data));data=fixture();data.sources[1].generatorEligible=true;assert.throws(()=>validateSources(data));});
test('only official HTTPS NPS video renditions are permitted; do not leak credentials',()=>{const id='e8a97d0e-155d-451f-67d96df7571f24dd';let a=staticCandidates(id);assert.ok(a.length>1);assert.ok(a.every(isAllowedMediaUrl));assert.ok(a.every(u=>u.includes(id)||u.includes(id.toUpperCase())));for(let u of ['https://evil.net/nps-audiovideo/audiovideo/x.mp4','https://www.nps.gov.evil.net/nps-audiovideo/audiovideo/x.mp4','http://www.nps.gov/nps-audiovideo/audiovideo/x.mp4','https://www.nps.gov/nps-audiovideo/audiovideo/x.mp4?secret=1','https://www.nps.gov/other/x.mp4'])assert.equal(isAllowedMediaUrl(u),false);});
test('HTML source parser accepts nps media only, dedupes, rejects unrelated CDN',()=>{const html='<video src="https://www.nps.gov/nps-audiovideo/audiovideo/X720p.mp4"></video> <video src="https://bad.com/nps-audiovideo/audiovideo/y.mp4"></video> <video src="https://www.nps.gov/nps-audiovideo/audiovideo/X720p.mp4"></video>';assert.deepEqual(extractMp4Urls(html),['https://www.nps.gov/nps-audiovideo/audiovideo/X720p.mp4']);});
test('official NPS B-roll index is fixed, not a web-crawling wildcard',()=>{assert.equal(OFFICIAL_INDEX,'https://www.nps.gov/grca/learn/photosmultimedia/b-roll_hd_index.htm');});

test('relative rendition URLs and different official media-version UUIDs are allowed on a scoped viewer page',()=>{
 const viewer='<source src="/nps-audiovideo/audiovideo/799af83a720p.mp4">'+
  '<source src="https:\\/\\/www.nps.gov\\/nps-audiovideo\\/audiovideo\\/799af83a480p.mp4">';
 assert.deepEqual(extractMp4Urls(viewer).sort(),[
  'https://www.nps.gov/nps-audiovideo/audiovideo/799af83a480p.mp4',
  'https://www.nps.gov/nps-audiovideo/audiovideo/799af83a720p.mp4'
 ].sort());
 assert.equal(isAllowedMediaUrl('https://www.nps.gov/nps-audiovideo/audiovideo/../../etc.mp4'),false);
});
