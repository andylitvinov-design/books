#!/usr/bin/env node
/** One-time, capped public source-page discovery. NO MP4 downloaded, NO publication. */
import {readFileSync,readdirSync,existsSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {SITE,LICENSE,parseListing,parseLicensedPage,uniqueCandidates,safeDarefulPage} from '../lib/video-vault/dareful-public-discovery.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const out=resolve(root,'artifacts/hh-dareful-wave4');
if(process.argv.slice(2).some(a=>a!=='--discover'))throw Error('unknown_option');
const repo=join(root,'data/video-catalog');
const excluded=new Set();
function collect(value,depth=0){
  if(depth>5||!value||typeof value!=='object')return;
  for(const [k,v] of Object.entries(value)){
    if((k==='sourcePage'||k==='originalSourcePage')&&typeof v==='string'){
      const normalized=safeDarefulPage(v);if(normalized)excluded.add(normalized);
    } else if(typeof v==='object')collect(v,depth+1);
  }
}
// Existing live material plus all previous research manifests, including unmerged waves.
for(const filename of readdirSync(repo)){
  if(!/^(free-stock-scenes|dareful[^/]*)\.json$/.test(filename))continue;
  try{collect(JSON.parse(readFileSync(join(repo,filename),'utf8')))}catch{throw Error('invalid_existing_manifest_'+filename)}
}
const extra=join(repo,'dareful-wave4-excluded-pr-pages-20261105.json');
if(!existsSync(extra))throw Error('missing_previous_pr_exclusion_manifest');
collect(JSON.parse(readFileSync(extra,'utf8')));
const MAX_LIST_PAGES=22,MAX_SOURCE_CHECKS=155,MAX_CANDIDATES=60;
async function fetchText(url){
  const r=await fetch(url,{redirect:'error',headers:{'User-Agent':'HolisticHouse-curation-research/1.0 (single-run; license provenance)'},signal:AbortSignal.timeout(18000)});
  if(!r.ok)throw Error('http_'+r.status);
  const ct=r.headers.get('content-type')||'';
  if(!ct.includes('text/html'))throw Error('invalid_content_type');
  if(Number(r.headers.get('content-length')||0)>2_000_000)throw Error('overlarge_html');
  const html=await r.text();
  if(html.length>2_000_000)throw Error('overlarge_html');
  return html;
}
const candidates=new Set(),listingErrors=[];
for(let p=1;p<=MAX_LIST_PAGES;p++){
  try{
    const html=await fetchText(p===1?SITE:SITE+'page/'+p+'/');
    for(const link of parseListing(html))if(!excluded.has(link))candidates.add(link);
  }catch(err){listingErrors.push({page:p,error:String(err.message).slice(0,60)})}
}
if(listingErrors.length>5)throw Error('source_listings_unavailable');
// Stable category variety: round-robin from site pagination rather than just most recent.
const pages=[...candidates].sort();
const collected=[],errors=[];
for(const page of pages.slice(0,MAX_SOURCE_CHECKS)){
  if(collected.length>=MAX_CANDIDATES)break;
  try{
    const source=parseLicensedPage(await fetchText(page),page);
    if(source)collected.push(source);else errors.push({page,error:'no_single_licensed_stream'});
  }catch(err){errors.push({page,error:String(err.message).slice(0,90)})}
  await new Promise(r=>setTimeout(r,350));
}
const sources=uniqueCandidates(collected,[...excluded]).slice(0,MAX_CANDIDATES);
const report={schemaVersion:'hh-dareful-wave4-research-v1',discoveredOn:'2026-11-05',
  source:'Dareful official source pages',sourcePageLicense:LICENSE,sourceCount:sources.length,
  priorUnmergedPRPagesExcluded:42,existingSourcesExcluded:excluded.size,
  inspectedIndexPages:MAX_LIST_PAGES,visitedDetailPages:Math.min(pages.length,MAX_SOURCE_CHECKS),
  listingErrors,verificationErrors:errors,
  footageRecordedInCloudflareR2:0,readyForPublication:0,
  publicationStatus:'CANDIDATE_PAGES_ONLY_NOT_LICENSE_OR_VISUAL_APPROVED',
  sources};
mkdirSync(out,{recursive:true});
writeFileSync(join(out,'discovered.json'),JSON.stringify(report,null,2)+'\n');
process.stdout.write(JSON.stringify({candidates:report.sourceCount,errors:errors.length,listingErrors:listingErrors.length,priorExcluded:excluded.size,mode:report.publicationStatus})+'\n');
if(sources.length<12)process.exitCode=1;
