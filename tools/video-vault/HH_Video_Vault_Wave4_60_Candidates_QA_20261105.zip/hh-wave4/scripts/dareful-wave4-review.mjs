#!/usr/bin/env node
/** Read-only private QA of wave-4 stock snippets; no R2, Supabase, public or registry writes. */
import {readFileSync,writeFileSync,mkdirSync,rmSync,statSync,existsSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {LICENSE} from '../lib/video-vault/dareful-public-discovery.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const found=JSON.parse(readFileSync(join(root,'artifacts/hh-dareful-wave4/discovered.json'),'utf8'));
if(found.schemaVersion!=='hh-dareful-wave4-research-v1'||
  found.readyForPublication!==0||found.footageRecordedInCloudflareR2!==0||
  !Array.isArray(found.sources)||found.sources.length<12||found.sources.length>60)
  throw Error('untrusted_wave4_research_report');
const args=process.argv.slice(2);
if(args.length!==1||!/^--shard=[0-3]$/.test(args[0]))throw Error('four_fixed_shards_required');
const shard=Number(args[0].slice(-1));
const out=join(root,'artifacts/hh-dareful-wave4-screen-'+shard);
mkdirSync(out,{recursive:true});
function cli(cmd,args,{binary=false,timeout=125000}={}){
 const p=spawnSync(cmd,args,{cwd:root,timeout,encoding:binary?null:'utf8',maxBuffer:4_000_000});
 if(p.error||p.status!==0)throw Error(cmd+'_failed_'+String(p.stderr||p.error).slice(-200));
 return p.stdout;
}
function sha(path){return createHash('sha256').update(readFileSync(path)).digest('hex')}
function validate(file,w,h){
 const probe=JSON.parse(cli('ffprobe',['-v','error','-show_streams','-show_format','-of','json',file]));
 const v=probe.streams.find(x=>x.codec_type==='video');
 const fps=String(v?.avg_frame_rate||'0/1').split('/').map(Number);
 const t=Number(probe.format?.duration),bytes=statSync(file).size;
 if(v?.codec_name!=='h264'||v.pix_fmt!=='yuv420p'||v.width!==w||v.height!==h||
    !fps[1]||Math.abs(fps[0]/fps[1]-24)>.1||t<4.8||t>5.2||bytes<60000)
   throw Error('geometry_codec_or_duration_fail');
 const frames=cli('ffmpeg',['-hide_banner','-loglevel','error','-nostdin','-i',file,
   '-vf','fps=1,scale=64:64,format=gray','-frames:v','5','-f','rawvideo','pipe:1'],{binary:true,timeout:30000});
 const size=64*64,n=Math.floor(frames.length/size);if(n<4)throw Error('frame_count');
 let maxStd=0,delta=0;
 for(let i=0;i<n;i++){
   const f=frames.subarray(i*size,(i+1)*size);let s=0,sq=0;
   for(const z of f){s+=z;sq+=z*z}
   const mean=s/size;maxStd=Math.max(maxStd,Math.sqrt(Math.max(0,sq/size-mean*mean)));
   if(i>0){const prior=frames.subarray((i-1)*size,i*size);
     let d=0;for(let j=0;j<size;j++)d+=Math.abs(f[j]-prior[j]);delta+=d/size;}
 }
 const motion=Number((delta/(n-1)).toFixed(3)),contrast=Number(maxStd.toFixed(2));
 return {bytes,durationSeconds:t,width:w,height:h,fps:24,motion,contrast,
   // Metric screening is NOT human artistic approval.
   technicalPass:motion>=.55&&contrast>=12};
}
function render(url,dest,w,h){
 cli('ffmpeg',['-hide_banner','-loglevel','error','-nostdin','-y','-rw_timeout','25000000',
   '-i',url,'-t','5','-an','-vf',`fps=24,scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h},setsar=1,format=yuv420p`,
   '-c:v','libx264','-preset','veryfast','-crf','25','-threads','2','-pix_fmt','yuv420p',
   '-movflags','+faststart',dest],{timeout:145000});
}
const entries=found.sources.filter((x,i)=>i%4===shard);
const result=[];
for(const x of entries){
 const p=join(out,x.id+'-portrait.mp4'),l=join(out,x.id+'-landscape.mp4');
 try{
   if(x.licenseUrl!==LICENSE||x.approvedForPublication!==false||
      !/^https:\/\/stream\.mux\.com\/[A-Za-z0-9]+\.m3u8$/.test(x.mediaUrl))
     throw Error('source_not_allowed');
   render(x.mediaUrl,l,1280,720);
   render(x.mediaUrl,p,720,1280);
   const lands=validate(l,1280,720),ports=validate(p,720,1280);
   if(!lands.technicalPass||!ports.technicalPass)throw Error('low_quality_motion_or_tonality');
   const thumb=join(out,x.id+'-poster.jpg'),sheet=join(out,x.id+'-contact.jpg');
   cli('ffmpeg',['-hide_banner','-loglevel','error','-nostdin','-y','-ss','2','-i',p,
     '-frames:v','1','-vf','scale=360:640','-q:v','4',thumb],{timeout:25000});
   cli('ffmpeg',['-hide_banner','-loglevel','error','-nostdin','-y','-i',p,
     '-vf','fps=1.8,scale=240:426,tile=3x3:nb_frames=9','-frames:v','1','-q:v','4',sheet],{timeout:25000});
   result.push({id:x.id,sourcePage:x.sourcePage,license:LICENSE,creator:'Joel Holland / Dareful',
     originalFilmingSourceId:x.id,landscape:{...lands,sha256:sha(l)},portrait:{...ports,sha256:sha(p)},
     portraitIsReframeOfLandscape:true,readyForPublication:false,artisticApproval:false,
     status:'technically_screened_needs_full_artistic_rights_R2_verification',
     outputs:{landscape:x.id+'-landscape.mp4',portrait:x.id+'-portrait.mp4',poster:x.id+'-poster.jpg',contact:x.id+'-contact.jpg'}});
 }catch(err){
   // Do not archive broken/short/inappropriate clips as technically eligible.
   for(const path of [p,l])if(existsSync(path))rmSync(path,{force:true});
   result.push({id:x.id,sourcePage:x.sourcePage,status:'rejected_or_source_failed',
     reason:String(err.message).slice(0,250),readyForPublication:false});
 }
 process.stdout.write(x.id+': '+result.at(-1).status+'\n');
}
const passed=result.filter(x=>x.status.startsWith('technically_')).length;
const report={schemaVersion:'hh-dareful-wave4-screen-v1',shard,screened:result.length,
 technicalPass:passed, technicalReject:result.length-passed,sourceCountedOncePerCameraMaster:true,
 uploadedCloudflareR2:0,productionReady:0,artisticReviewed:false,
 rightsAndModelReleaseReviewPending:true,publicationStatus:'PRIVATE_QA_ONLY',sources:result};
writeFileSync(join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
process.stdout.write(JSON.stringify({shard,passed,checked:result.length})+'\n');
