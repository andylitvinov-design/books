import test from 'node:test';
import assert from 'node:assert/strict';
import {safeDarefulPage,parseListing,parseLicensedPage,uniqueCandidates} from '../lib/video-vault/dareful-public-discovery.mjs';
const page='https://dareful.com/snow-river-forest/';
const html='<h1>Snow River Forest</h1><a href="https://creativecommons.org/licenses/by/4.0/">CC BY 4.0</a><a href="https://stream.mux.com/ABC0123xyz.m3u8">Download</a> Duration —00:24';
test('page paths restricted to safe official unparameterized video candidates',()=>{
 assert.equal(safeDarefulPage('https://dareful.com/snow-river-forest'),page);
 for(const unsafe of ['http://dareful.com/a/','https://dareful.com.evil.com/a/','https://dareful.com/page/2/', 'https://dareful.com/a?next=x','https://dareful.com/a/#foo','https://dareful.com/@evil/','https://dareful.com/%2e%2e/'])assert.equal(safeDarefulPage(unsafe),null);
});
test('listing extraction removes nav, malicious hosts, duplicate pages',()=>{
 const links=parseListing(`<a href="${page}">film</a><a href="${page}">again</a><a href="https://dareful.com/page/3/">next</a><a href="https://evil.com/a/">bad</a>`);
 assert.deepEqual(links,[page]);
});
test('licensed official Mux source contains auditable rights metadata and remains unapproved',()=>{
 const s=parseLicensedPage(html,page);assert.equal(s.id,'snow-river-forest');assert.equal(s.durationSeconds,24);
 assert.equal(s.mediaUrl,'https://stream.mux.com/ABC0123xyz.m3u8');
 assert.equal(s.approvedForPublication,false);assert.equal(s.cloudflareR2UploadVerified,false);
});
test('reject missing license, forged stream, multiple streams, redirect-style source page',()=>{
 assert.equal(parseLicensedPage('<h1>x</h1><a href="https://stream.mux.com/ABC0123xyz.m3u8">video</a>',page),null);
 assert.equal(parseLicensedPage(html.replace('stream.mux.com','steal.invalid'),page),null);
 assert.equal(parseLicensedPage(html+'https://stream.mux.com/OTHER123.m3u8',page),null);
 assert.throws(()=>parseLicensedPage(html,'https://dareful.com.evil.org/film/'));
});
test('existing and PR candidate pages excluded, no double-count of same stream',()=>{
 const a=parseLicensedPage(html,page),b={...a,id:'different',sourcePage:'https://dareful.com/different/',mediaUrl:a.mediaUrl};
 assert.deepEqual(uniqueCandidates([a,b],[]).map(x=>x.id),[a.id]);
 assert.deepEqual(uniqueCandidates([a,b],[page]).map(x=>x.id),[b.id]);
});
